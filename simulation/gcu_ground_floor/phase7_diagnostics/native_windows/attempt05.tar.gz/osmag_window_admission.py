"""Fail-closed window/constraint consumption gate, without any motion transport."""
import hashlib
import numpy as np
from osmag_constraint_mask import ConsumptionGate,ConstraintError
from gcu_plan_validation import validate_path


class WindowAdmission(ConsumptionGate):
    def __init__(self,window,snapshot,published_at,free_probes):
        if (snapshot.mask.shape!=window.grid.shape or snapshot.origin!=window.origin
                or snapshot.resolution!=window.resolution or snapshot.mask_revision!=window.revision
                or snapshot.physical_sha256!=hashlib.sha256(np.ascontiguousarray(window.grid,dtype=np.int16).tobytes()).hexdigest()):
            raise ConstraintError('window_constraint_snapshot_mismatch')
        super().__init__(snapshot,published_at,free_probes)
        self.window=window

    def observe(self,source,grid,resolution,origin,stamp,now,**kwargs):
        self.observations.pop(source,None)
        if source=='global' and (np.asarray(grid).shape!=self.window.grid.shape
                or any(abs(a-b)>1e-7 for a,b in zip(origin,self.window.origin))):
            raise ConstraintError('native_global_window_geometry_mismatch')
        return super().observe(source,grid,resolution,origin,stamp,now,**kwargs)

    def admit(self,goal,now):
        if goal.window_sha256!=self.window.sha256 or goal.window_revision!=self.window.revision:
            raise ConstraintError('obsolete_proxy_window')
        if not self.ready(now):raise ConstraintError('window_constraints_not_freshly_consumed')
        check=validate_path(self.snapshot.combined,self.snapshot.resolution,self.snapshot.origin,
                            goal.prefix,self.snapshot.radius+self.snapshot.padding)
        if not check['valid']:raise ConstraintError('proxy_prefix_blocked_by_constraint')
        return dict(window_sha256=self.window.sha256,window_revision=self.window.revision,
                    mask_sha256=self.snapshot.mask_sha256,observed_at=now,scope='Admission only; not an action dispatch')
