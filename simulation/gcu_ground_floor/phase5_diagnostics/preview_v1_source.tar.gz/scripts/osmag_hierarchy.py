"""Paper-based reference hierarchy search; not the unreleased authors' source.

Cache shortest traces within child subtrees, lift endpoint costs to their exposed
passages, search the lowest-common-ancestor compact graph, then expand traces.
Disabled nodes use separate caches so a previously cached route cannot bypass a
closure. Costs and geometry are supplied by the footprint-checked raster layer.
"""
import heapq
import itertools
import math


def shortest(graph, source, allowed=None, target=None, heuristic=None):
    distances={source:0.};previous={};counter=itertools.count()
    queue=[(0.,next(counter),0.,source)]
    while queue:
        _,_,cost,node=heapq.heappop(queue)
        if cost!=distances[node]:continue
        if node==target:break
        for neighbor,weight in graph.get(node,{}).items():
            if allowed is not None and neighbor not in allowed:continue
            candidate=cost+weight
            if candidate<distances.get(neighbor,math.inf)-1e-12:
                distances[neighbor]=candidate;previous[neighbor]=node
                estimate=heuristic(neighbor) if heuristic else 0.
                heapq.heappush(queue,(candidate+estimate,next(counter),candidate,neighbor))
    return distances,previous


def trace(previous, source, target):
    result=[target]
    while result[-1]!=source:
        if result[-1] not in previous:return []
        result.append(previous[result[-1]])
    return result[::-1]


class HierarchyGraph:
    def __init__(self, points, graph, owners, parents):
        self.points=points;self.graph=graph;self.owners=owners;self.parents=parents
        self.cache={};self.compact_cache={}
        for area in parents:self.ancestors(area)

    def ancestors(self, area):
        result=[]
        while area is not None:
            if area in result:raise ValueError('cyclic_hierarchy')
            result.append(area);area=self.parents.get(area)
        return result

    def lca(self, first, second):
        other=set(self.ancestors(second))
        return next((a for a in self.ancestors(first) if a in other),None)

    def nodes(self, area, disabled):
        return {n for n,owner in self.owners.items() if n not in disabled and area in self.ancestors(owner)}

    def boundary(self, area, disabled):
        inside=self.nodes(area,disabled)
        return sorted(n for n in inside if any(m not in inside and m not in disabled for m in self.graph[n]))

    def within(self, area, source, disabled):
        key=(area,source,disabled)
        if key not in self.cache:self.cache[key]=shortest(self.graph,source,self.nodes(area,disabled))
        return self.cache[key]

    def child(self, leaf, ancestor):
        chain=self.ancestors(leaf)
        return leaf if leaf==ancestor else chain[chain.index(ancestor)-1]

    def compact(self, area, disabled):
        key=(area,disabled)
        if key in self.compact_cache:return self.compact_cache[key]
        children=[a for a,p in self.parents.items() if p==area]
        graph={};traces={};inside=self.nodes(area,disabled)
        def edge(a,b,cost,path):
            if cost<graph.setdefault(a,{}).get(b,math.inf):
                graph[a][b]=cost;graph.setdefault(b,{})[a]=cost
                traces[a,b]=path;traces[b,a]=path[::-1]
        if not children:
            for a in inside:
                for b,w in self.graph[a].items():
                    if b in inside:edge(a,b,w,[a,b])
        else:
            for child in children:
                boundary=self.boundary(child,disabled)
                for i,a in enumerate(boundary):
                    graph.setdefault(a,{})
                    distances,previous=self.within(child,a,disabled)
                    for b in boundary[i+1:]:
                        if b in distances:edge(a,b,distances[b],trace(previous,a,b))
            for a in inside:
                for b,w in self.graph[a].items():
                    if b in inside and self.child(self.owners[a],area)!=self.child(self.owners[b],area):edge(a,b,w,[a,b])
        self.compact_cache[key]=(graph,traces)
        return graph,traces

    def lift(self, child, attachments, disabled):
        lifted={}
        for boundary in self.boundary(child,disabled):
            distances,previous=self.within(child,boundary,disabled)
            choices=[(cost+distances[n],n) for n,cost in attachments.items() if n in distances and n not in disabled]
            if choices:
                cost,node=min(choices)
                lifted[boundary]=(cost,trace(previous,boundary,node)[::-1])
        return lifted

    def route(self, start_area, goal_area, start, goal, start_xy, goal_xy, disabled=()):
        disabled=frozenset(disabled);ancestor=self.lca(start_area,goal_area)
        if ancestor is None:raise ValueError('disconnected_hierarchy')
        original,stored=self.compact(ancestor,disabled)
        graph={n:dict(edges) for n,edges in original.items()};paths=dict(stored)
        def attach(name, area, attachments):
            child=self.child(area,ancestor)
            frontier=self.lift(child,attachments,disabled)
            graph[name]={}
            for node,(cost,path) in frontier.items():
                graph[name][node]=cost;graph.setdefault(node,{})[name]=cost
                paths[name,node]=path;paths[node,name]=path[::-1]
        attach('@start',start_area,start);attach('@goal',goal_area,goal)
        def heuristic(node):
            point=start_xy if node=='@start' else goal_xy if node=='@goal' else self.points[node]
            return math.dist(point,goal_xy)
        distances,previous=shortest(graph,'@start',target='@goal',heuristic=heuristic)
        if '@goal' not in distances:raise ValueError('no_feasible_graph_route')
        walk=trace(previous,'@start','@goal');expanded=[]
        for a,b in zip(walk,walk[1:]):
            part=paths[a,b]
            expanded.extend(part[1:] if expanded and expanded[-1]==part[0] else part)
        return {'cost_m':distances['@goal'],'nodes':expanded,'lca':ancestor,
                'compact_search_nodes':len(graph),'base_nodes':len(self.points),
                'method':'paper_based_cached_child_traces_lca_astar_expand'}
