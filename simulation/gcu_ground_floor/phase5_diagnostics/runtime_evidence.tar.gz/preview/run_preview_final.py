import time,json,subprocess
from pathlib import Path
w=Path('/home/ubuntu/edgeosmag_phase5_ws');p=Path('/home/ubuntu/edgeosmag_phase5_preview_ws')
gate=w/'results/05A/ordered_wait_final_02/reliability_gates.json'
while True:
 try:
  result=json.loads(gate.read_text())
  if result.get('passed') or result.get('error'):break
 except (OSError,ValueError):pass
 time.sleep(2)
cmd=['python3',str(p/'run_gcu_osmag_preview_test.py'),'--navigation-workspace',str(w),'--preview-workspace',str(p),'--output',str(p/'results/live_05')]
r=subprocess.run(cmd)
(p/'results/live05_complete.json').write_text(json.dumps({'exit':r.returncode}))
