import pathlib,json,time,subprocess
p=pathlib.Path('/home/ubuntu/edgeosmag_phase5_preview_ws');w=pathlib.Path('/home/ubuntu/edgeosmag_phase5_ws')
gate=w/'results/05A/final_candidate/reliability_gates.json';deadline=time.monotonic()+7200
while time.monotonic()<deadline:
 d=json.loads(gate.read_text())
 if d.get('passed') or 'error' in d:break
 time.sleep(5)
else:raise RuntimeError('Metric gates did not finish; preview not started')
print('Metric gate outcome: '+str(d.get('passed')),flush=True)
r=subprocess.run(['python3',str(p/'run_gcu_osmag_preview_test.py'),'--navigation-workspace',str(w),'--preview-workspace',str(p),'--output',str(p/'results/live_01')])
(p/'results/live_complete.json').write_text(json.dumps({'exit':r.returncode,'metric_gate_passed':d.get('passed',False)}))
