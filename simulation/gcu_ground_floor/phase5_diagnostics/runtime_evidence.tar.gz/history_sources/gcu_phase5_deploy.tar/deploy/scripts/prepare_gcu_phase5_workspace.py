#!/usr/bin/env python3
"""Prepare a new isolated Phase 05 workspace; keep Phase 04 evidence/runtime intact."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def prepare(destination):
    source = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(source/'prepare_gcu_phase4_workspace.py'),
                    '--destination', str(destination)], check=True)
    target = Path(destination).resolve()
    shutil.copy2(source.parent/'simulation/gcu_ground_floor/nav2_handoff.yaml',
                 target/'assets/nav2_autonomous.yaml')
    shutil.copy2(source/'run_gcu_phase5_navigation_test.py', target/'run_gcu_navigation_test.py')
    shutil.copy2(source/'gcu_process_audit.py', target/'gcu_process_audit.py')
    manifest = {'scope': 'Phase 05 candidate; upstream rotation shim and ordered bridge shutdown',
                'files_sha256': {str(p.relative_to(target)): hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in sorted(target.rglob('*')) if p.is_file()}}
    (target/'phase5_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', required=True, type=Path)
    prepare(parser.parse_args().destination)
