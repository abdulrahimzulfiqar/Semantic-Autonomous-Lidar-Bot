import pathlib,subprocess,json,sys,hashlib
w=pathlib.Path('/home/ubuntu/edgeosmag_phase5_ws');base=w/'results/05A';summary={'passed':False,'trials':[]}
def save():(base/'reliability_gates.json').write_text(json.dumps(summary,indent=2))
save()
try:
 for i in range(1,9):
  serial=i<=3;name=('serial_'+str(i).zfill(2)) if serial else ('shutdown_'+str(i-3).zfill(2));out=base/name
  cmd=['python3',str(w/'run_gcu_navigation_test.py'),'--workspace',str(w),'--robot-workspace','/home/ubuntu/lidarbot_ws','--domain',str(121+i),'--output',str(out)]
  if serial:cmd+=['--execute','--sim-timeout','150','--wall-timeout','870','--follow-up-goal','-0.05864395131342248','-12.960313240266368','0']
  else:cmd+=['--positive-control','--sim-timeout','30','--wall-timeout','180']
  print('Starting '+name,flush=True);r=subprocess.run(cmd);summary['trials'].append({'name':name,'exit':r.returncode});save()
  if r.returncode:raise RuntimeError('Gate failed: '+name)
 print('Starting unchanged original matrix with Phase 05 profile',flush=True)
 out=base/'matrix_01';r=subprocess.run(['python3',str(w/'run_gcu_navigation_suite.py'),'--execute','--workspace',str(w),'--robot-workspace','/home/ubuntu/lidarbot_ws','--domain','140','--output',str(out)])
 summary['matrix_exit']=r.returncode
 if r.returncode:raise RuntimeError('Original matrix regression failed')
 summary['passed']=True
except Exception as e:summary['error']=str(e)
finally:save()
