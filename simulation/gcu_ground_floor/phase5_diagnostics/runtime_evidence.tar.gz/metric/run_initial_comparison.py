import pathlib,subprocess,json
root=pathlib.Path('/home/ubuntu/edgeosmag_phase5_ws');base=root/'results/05A';summary=[]
for name,ws,domain in [('baseline_serial_01','/home/ubuntu/edgeosmag_test_ws',120),('shim_serial_candidate_01',str(root),121)]:
 cmd=['python3',ws+'/run_gcu_navigation_test.py','--execute','--workspace',ws,'--robot-workspace','/home/ubuntu/lidarbot_ws','--domain',str(domain),'--output',str(base/name),'--sim-timeout','150','--wall-timeout','870','--follow-up-goal','-0.05864395131342248','-12.960313240266368','0']
 print('Starting '+name,flush=True);r=subprocess.run(cmd)
 summary.append({'name':name,'exit':r.returncode});(base/'initial_comparison.json').write_text(json.dumps(summary,indent=2))
 if name.startswith('shim') and r.returncode:break
