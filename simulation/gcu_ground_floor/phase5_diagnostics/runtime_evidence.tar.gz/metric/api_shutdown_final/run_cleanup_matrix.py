import pathlib,subprocess,json,time,sys
w=pathlib.Path('/home/ubuntu/edgeosmag_phase5_ws');base=w/'results/05A/api_shutdown_final';summary={'passed':False,'trials':[],'serial_source':'../final_candidate/serial_01..03 (same controller and truth bridge; teardown API change only)'}
def save():(base/'summary.json').write_text(json.dumps(summary,indent=2))
save()
preview=pathlib.Path('/home/ubuntu/edgeosmag_phase5_preview_ws/results/live_02/run.json');deadline=time.monotonic()+600
while not preview.exists() and time.monotonic()<deadline:time.sleep(2)
assert preview.exists(),'Preview did not finish'
r=json.loads(preview.read_text());assert r.get('simulator_stop',{}).get('passed') and not r['child_audit']['critical'],'Service shutdown smoke failed'
sys.path.insert(0,str(w))
from run_gcu_navigation_suite import hashes
frozen=hashes(w);(base/'frozen_inputs.json').write_text(json.dumps(frozen,indent=2))
try:
 for i in range(1,6):
  assert hashes(w)==frozen,'Runtime changed after freeze'
  name='shutdown_'+str(i).zfill(2);print('Starting '+name,flush=True)
  cmd=['python3',str(w/'run_gcu_navigation_test.py'),'--workspace',str(w),'--robot-workspace','/home/ubuntu/lidarbot_ws','--domain',str(130+i),'--output',str(base/name),'--positive-control','--sim-timeout','30','--wall-timeout','180']
  r=subprocess.run(cmd);summary['trials'].append({'name':name,'exit':r.returncode});save()
  if r.returncode:raise RuntimeError('Shutdown gate failed: '+name)
 print('Starting original frozen functional matrix',flush=True)
 r=subprocess.run(['python3',str(w/'run_gcu_navigation_suite.py'),'--execute','--workspace',str(w),'--robot-workspace','/home/ubuntu/lidarbot_ws','--domain','140','--output',str(base/'matrix_01')])
 summary['matrix_exit']=r.returncode
 if r.returncode:raise RuntimeError('Original matrix failed')
 summary['passed']=True
except Exception as e:summary['error']=str(e)
finally:save()
