#!/usr/bin/env python3
"""Prepare a fresh 06B2B VM workspace; never start or modify installed robots."""
import argparse,hashlib,json,shutil
import xml.etree.ElementTree as ET
from pathlib import Path


def prepare(baseline,source_assets,destination):
    import yaml
    source=Path(__file__).parent
    shutil.copytree(baseline,destination,ignore=shutil.ignore_patterns('results','*manifest*.json','__pycache__'))
    (destination/'results').mkdir()
    for path in (destination/'assets').rglob('*'):
        if path.is_file() and path.suffix in ['.sdf','.urdf','.yaml']:path.write_text(path.read_text().replace(str(baseline),str(destination)))
    for name in ['gcu_segmented_executor.py','check_gcu_segmented_crossing.py','run_gcu_segmented_crossing.py',
                 'osmag_mission_contract.py','osmag_mission_state.py','osmag_paper_planner.py','osmag_hierarchy.py',
                 'osmag_route_refinement.py','audit_gcu_interfaces.py','gcu_navigation_metrics.py']:
        shutil.copy2(source/name,destination/name)
    for name in ['gcu_ground_floor.osm','regions_pixels.geojson']:
        shutil.copy2(source_assets/name,destination/'assets'/name)
    contact=destination/'assets/contact_v2';robot=ET.parse(contact/'robot.sdf')
    collisions=[]
    for link in robot.findall('./model/link'):
        for sensor in link.findall('sensor'):
            if sensor.get('type')!='contact':continue
            collision=sensor.findtext('contact/collision');topic=sensor.findtext('topic')
            if collision not in [c.get('name') for c in link.findall('collision')] or not topic or not topic.startswith('/gcu/contacts/'):
                raise ValueError('invalid_instrumented_collision')
            collisions.append({'link':link.get('name'),'collision':collision,'topic':topic})
    if len(collisions)!=13 or len({v['topic'] for v in collisions})!=13:raise ValueError('contact_contract_changed')
    (contact/'contact_manifest.json').write_text(json.dumps({'collisions':collisions,'source':'Existing instrumented SDF, unchanged collisions'},indent=2)+'\n')
    sim=(destination/'gcu_phase5_sim.launch.py').read_text().replace("'-x', '-0.05864395131342248'", "'-x', '-0.5'")
    (destination/'gcu_phase6_sim.launch.py').write_text(sim)
    class PlainDumper(yaml.SafeDumper):
        def ignore_aliases(self,data):return True
    amcl=yaml.safe_load((destination/'assets/amcl.yaml').read_text());amcl['amcl']['ros__parameters']['initial_pose']['x']=-.5
    (destination/'assets/amcl.yaml').write_text(yaml.dump(amcl,Dumper=PlainDumper,sort_keys=False))
    params=yaml.safe_load((destination/'assets/nav2_sensor_constraints.yaml').read_text())
    bt=params['bt_navigator']['ros__parameters'];bt['default_nav_to_pose_bt_xml']=str(destination/'assets/navigate_strict.xml');bt['default_nav_through_poses_bt_xml']=str(destination/'assets/navigate_through_strict.xml')
    (destination/'assets/nav2_sensor_constraints.yaml').write_text(yaml.dump(params,Dumper=PlainDumper,sort_keys=False))
    # This full stack has more participants than CycloneDDS's default automatic
    # index range. Keep loopback-only discovery, with enough explicit indices.
    (destination/'assets/cyclonedds_local.xml').write_text('''<CycloneDDS><Domain id="any"><General><AllowMulticast>false</AllowMulticast></General><Discovery><ParticipantIndex>auto</ParticipantIndex><MaxAutoParticipantIndex>100</MaxAutoParticipantIndex><Peers><Peer Address="127.0.0.1"/></Peers></Discovery></Domain></CycloneDDS>\n''')
    files={str(p.relative_to(destination)):hashlib.sha256(p.read_bytes()).hexdigest() for p in destination.rglob('*') if p.is_file()}
    (destination/'crossing_manifest.json').write_text(json.dumps({'scope':'06B2B single simulation crossing; explicit execute required','baseline':str(baseline),
        'spawn':[-.5,-12.960313240266368,0.],'goal':[1.4413560486865775,-12.960313240266368,0.],
        'simulation_timeout_s':80,'checker_wall_timeout_s':420,'global_grid_age_s':.75,'local_grid_age_s':.5,
        'files_sha256':files},indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--source-assets',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
    prepare(a.baseline,a.source_assets,a.destination)
