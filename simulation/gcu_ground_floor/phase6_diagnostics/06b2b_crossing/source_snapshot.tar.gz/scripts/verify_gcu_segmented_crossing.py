#!/usr/bin/env python3
"""Replay physical, topology, handoff and rest evidence for the short crossing."""
import argparse,hashlib,io,json,math,tarfile
from dataclasses import replace
from pathlib import Path
import numpy as np
from gcu_plan_validation import validate_path
from gcu_navigation_metrics import rest_window,coverage,velocities
from osmag_paper_planner import PaperPlanner
from osmag_mission_contract import make_contract,CrossingMonitor


def verify(folder):
    manifest=json.loads((folder/'manifest.json').read_text());root=Path(__file__).resolve().parents[1]
    for n,digest in manifest['artifacts_sha256'].items():assert hashlib.sha256((folder/n).read_bytes()).hexdigest()==digest,n
    for n,digest in manifest['source_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==digest,n
    with tarfile.open(folder/'attempt06.tar.gz') as t:
        report=json.loads(t.extractfile('results/crossing_06/report.json').read());run=json.loads(t.extractfile('results/crossing_06/run.json').read())
        arrays=np.load(io.BytesIO(t.extractfile('results/crossing_06/constraint.npz').read()))
    result={'verification_passed':False,'trial_passed':bool(report['passed'] and run['passed']),'motion_attempted':True}
    result['runtime_error']=report.get('error');result['shutdown_passed']=run['simulator_shutdown']['passed']
    if not result['trial_passed']:
        result['verification_passed']=True;result['scope']='Failed trial retained; no successful crossing/arrival claim.';return result
    planner=PaperPlanner(root/'simulation/gcu_ground_floor');stored=report['contract']
    contract=make_contract(planner,stored['start'],stored['goal'][:2],stored['goal'][2],mission_id=stored['mission_id'],now=stored['created_at'],pose_stamp=stored['pose_stamp'])
    assert contract.route_sha256==stored['route_sha256'] and contract.passage_ids==('-93',)
    truth=report['truth'];monitor=CrossingMonitor(replace(contract,start=tuple(truth[0]['truth'][:2]),pose_stamp=truth[0]['sim_time']),planner.leaves,planner.passage_segments)
    for row in truth[1:]:monitor.observe(row['truth'][:2],row['sim_time'])
    assert monitor.confirmed==1
    assert validate_path(arrays['combined'],planner.resolution,planner.origin,[v['truth'][:2] for v in truth],.18)['valid']
    final=truth[-1]['truth'];position=math.dist(final[:2],stored['goal'][:2]);heading=math.degrees(abs(math.atan2(math.sin(final[2]-stored['goal'][2]),math.cos(final[2]-stored['goal'][2]))))
    assert position<=.20 and heading<=10 and not report['contacts']
    events=report['events'];sends=[e for e in events if e['event']=='send'];assert len(sends)==2
    old=next(e['uuid'] for e in events if e['event']=='accepted' and e['token']==sends[0]['token'])
    end=next(e for e in events if e['event']=='result' and e['uuid']==old);assert sends[1]['wall']<end['wall']
    terminal=next(e for e in events if e['event']=='result' and e['outcome']=='succeeded');assert rest_window(truth,earliest=terminal['sim']) is not None
    cov=coverage(truth,report['localization']);assert cov['matched_fraction']>=.9 and cov['max_truth_gap_sim_s']<=.15
    assert np.percentile([r['position_error_m'] for r in report['localization']],95)<=.25
    assert np.percentile([r['yaw_error_deg'] for r in report['localization']],95)<=5
    assert max(abs(r['v']) for r in report['commands'])<=.10001
    slow_start=None;longest=0.
    for row in velocities(truth):
        if not sends[1]['sim']-.5<=row['sim_time']<=sends[1]['sim']+2:continue
        if row['v']<=.01 and row['w']<=.02:
            if slow_start is None:slow_start=row['sim_time']
            longest=max(longest,row['sim_time']-slow_start)
        else:slow_start=None
    assert longest<1.
    assert run['process_exits']==[0]*5 and not run['audit']['critical'] and run['truth_shutdown']['passed']
    result.update(verification_passed=True,position_error_m=position,heading_error_deg=heading,
        confirmed_passages=[e['passage_id'] for e in monitor.events],handoff_before_terminal=True,
        longest_handoff_rest_sim_s=longest,coverage=cov)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
    result=verify(a.evidence);(a.evidence/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
