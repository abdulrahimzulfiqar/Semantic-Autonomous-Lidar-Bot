"""Read only explicitly admitted, versioned simulation mission fixtures."""
import hashlib,json,math
from pathlib import Path


def load_fixture(path):
    path=Path(path);data=json.loads(path.read_text())
    if not isinstance(data.get('name'),str) or not data['name']:raise ValueError('missing_fixture_name')
    for name in ['spawn','goal']:
        if len(data.get(name,[]))!=3 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in data[name]):raise ValueError('invalid_fixture_pose')
    passages=data.get('expected_passages',[]);areas=data.get('expected_areas',[])
    if not passages or len(set(passages))!=len(passages) or not all(isinstance(v,str) for v in passages) or len(areas)!=len(passages)+1:raise ValueError('invalid_fixture_topology')
    if not data.get('mask_validation',{}).get('valid'):raise ValueError('fixture_padding_not_validated')
    if not 0<data.get('simulation_timeout_s',0)<=180 or not 0<data.get('checker_wall_timeout_s',0)<=850:raise ValueError('invalid_fixture_deadlines')
    if not data.get('input_sha256'):raise ValueError('missing_fixture_inputs')
    return data,hashlib.sha256(path.read_bytes()).hexdigest()


def verify_runtime_sources(fixture,directory):
    for name,digest in fixture.get('execution_source_sha256',{}).items():
        if Path(name).name!=name or hashlib.sha256((Path(directory)/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('fixture_execution_source_changed:'+name)


def validate_current_contract(contract,snapshot):
    """Recheck the freshly localized route; a fixture proves only its own start."""
    from gcu_plan_validation import validate_path
    result=validate_path(snapshot.combined,snapshot.resolution,snapshot.origin,contract.path,snapshot.radius+snapshot.padding)
    if not result['valid']:raise ValueError('current_contract_padding_not_validated:'+json.dumps(result,sort_keys=True))
    return result
