import tarfile,json,io,math,numpy as np,cv2
with tarfile.open('/tmp/gcu_return_capture03_attempt.tar.gz') as t:
 r=json.load(t.extractfile('results/consecutive_03/report.json'));f=r['failed_mission'];a=np.load(io.BytesIO(t.extractfile('results/consecutive_03/constraint_2.npz').read()));physical=a['physical'];s=f['snapshot'];res=s['resolution'];origin=s['origin'];d=cv2.distanceTransform((physical!=100).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE)*res
 cap=f['native_captures'][-1];out=[]
 for scan in cap['scans']:
  if 'map_from_scan' not in scan:continue
  ranges=np.load(io.BytesIO(t.extractfile('results/consecutive_03/'+scan['file']).read()))['ranges'];angles=scan['angle_min']+np.arange(len(ranges))*scan['angle_increment'];keep=np.isfinite(ranges)&(ranges>=scan['range_min'])&(ranges<scan['range_max']);rr=ranges[keep];ang=angles[keep]
  pair=min(r['localization'],key=lambda p:abs(p['sim_time']-scan['stamp']));est=pair['estimated'];truth=pair['truth'];m=scan['map_from_scan'];yawdiff=truth[2]-est[2];dx=m[0]-est[0];dy=m[1]-est[1]
  true_scan=[truth[0]+math.cos(yawdiff)*dx-math.sin(yawdiff)*dy,truth[1]+math.sin(yawdiff)*dx+math.cos(yawdiff)*dy,m[2]+yawdiff]
  row={'stamp':scan['stamp'],'yaw_error_deg':pair['yaw_error_deg']}
  for label,pose in [('estimated',m),('truth_evaluation_only',true_scan)]:
   xx=pose[0]+rr*np.cos(ang+pose[2]);yy=pose[1]+rr*np.sin(ang+pose[2]);cc=np.floor((xx-origin[0])/res).astype(int);rows=np.floor((yy-origin[1])/res).astype(int);inside=(cc>=0)&(cc<d.shape[1])&(rows>=0)&(rows<d.shape[0]);dist=d[rows[inside],cc[inside]];row[label]={'median_endpoint_wall_distance_m':float(np.median(dist)),'mean_capped_0_5m':float(np.mean(np.minimum(dist,.5))),'beams':len(dist)}
  out.append(row)
 print(json.dumps(out,indent=2));open('/tmp/gcu_return_alignment.json','w').write(json.dumps(out,indent=2))
