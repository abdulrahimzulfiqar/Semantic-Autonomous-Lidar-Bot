import json,tarfile,io,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
with tarfile.open('/tmp/gcu_return_capture03_attempt.tar.gz') as t:
 prefix='results/consecutive_03/';r=json.load(t.extractfile(prefix+'report.json'));f=r['failed_mission'];caps=f['native_captures'];s=f['snapshot'];arrays=np.load(io.BytesIO(t.extractfile(prefix+'constraint_2.npz').read()));combined=arrays['combined'];before=np.load(io.BytesIO(t.extractfile(prefix+'leg_2_dispatch_global_raw.npz').read()))['data'];after=np.load(io.BytesIO(t.extractfile(prefix+'failure_global_raw.npz').read()))['data'];res=caps[-1]['grids']['global_raw']['resolution'];ox,oy=caps[-1]['grids']['global_raw']['origin'];c0=int((23.-ox)/res);c1=int((25.1-ox)/res);r0=int((16.7-oy)/res);r1=int((18.2-oy)/res)
 new=(after==254)&(before!=254)&(combined==0);print('new lethal cells in originally permitted cells',int(new[r0:r1,c0:c1].sum()))
 fig,axes=plt.subplots(1,3,figsize=(12,4),sharex=True,sharey=True)
 for ax,data,title in zip(axes,[(combined!=0).astype(int),before,after],['Original physical + logical constraints','Return dispatch: target cost 154','After turn: target cost 253']):
  ax.imshow(data[r0:r1,c0:c1],origin='lower',extent=[ox+c0*res,ox+c1*res,oy+r0*res,oy+r1*res],interpolation='nearest',cmap='gray_r',vmin=0,vmax=1 if data is not before and data is not after else 254)
  cap=caps[0] if ax is axes[1] else caps[-1];goal=cap['segment'];pose=cap['pose'];ax.plot(*goal,'g*',markersize=12,label='Passage target');ax.plot(*pose[:2],'bo',markersize=5,label='Estimated robot');ax.arrow(pose[0],pose[1],.15*np.cos(pose[2]),.15*np.sin(pose[2]),color='b',head_width=.03)
  ax.set_title(title,fontsize=10);ax.set_xlabel('map x (m)');ax.set_aspect('equal')
 rr,cc=np.where(new[r0:r1,c0:c1]);axes[-1].scatter(ox+(cc+c0+.5)*res,oy+(rr+r0+.5)*res,c='red',s=12,label='New lethal, original free')
 axes[0].set_ylabel('map y (m)');axes[-1].legend(loc='lower left',fontsize=7);fig.suptitle('Consecutive return failure: unchanged doorway, altered native costmap');fig.tight_layout();fig.savefig('/tmp/gcu_return_native_costmaps.png',dpi=160)
