"""Inspect native occupancy grids in their stamped planar frame, without ROS.

These are observed-cell checks, not a certificate for a swept robot footprint.
Keep native grids and transforms for independent replay.
"""
import math
import numpy as np
from osmag_constraint_mask import ConstraintError


def inspect(snapshot, data, resolution, origin, map_from_grid, probes, *, full=False):
    data=np.asarray(data)
    if data.ndim!=2 or not data.size or not np.isin(data,range(-1,101)).all():
        raise ConstraintError('invalid_native_occupancy_grid')
    if not all(math.isfinite(v) for v in [resolution,*origin,*map_from_grid]) or resolution<=0:
        raise ConstraintError('invalid_native_geometry')
    # OccupancyGrid resolution is float32; accept exactly that serialization,
    # rather than widening the geometric tolerance arbitrarily.
    if resolution not in [snapshot.resolution,float(np.float32(snapshot.resolution))]:
        raise ConstraintError('unvalidated_native_resolution')
    tx,ty,yaw=map_from_grid;c=math.cos(yaw);s=math.sin(yaw)
    rows,cols=np.mgrid[:data.shape[0],:data.shape[1]]
    gx=origin[0]+(cols+.5)*resolution;gy=origin[1]+(rows+.5)*resolution
    x=tx+c*gx-s*gy;y=ty+s*gx+c*gy
    sr=np.floor((y-snapshot.origin[1])/snapshot.resolution).astype(int)
    sc=np.floor((x-snapshot.origin[0])/snapshot.resolution).astype(int)
    inside=(sr>=0)&(sc>=0)&(sr<snapshot.mask.shape[0])&(sc<snapshot.mask.shape[1])
    if not inside.any():raise ConstraintError('no_native_mask_overlap')
    if full:
        if abs(yaw)>1e-10 or math.dist([tx+origin[0],ty+origin[1]],snapshot.origin)>1e-6 or data.shape!=snapshot.mask.shape:
            raise ConstraintError('global_grid_geometry_changed')
    required=np.zeros_like(inside);required[inside]=snapshot.mask[sr[inside],sc[inside]]==100
    missed=required&(data>=0)&(data<100)
    checked=0
    for px,py in probes:
        dx=px-tx;dy=py-ty
        col=math.floor((c*dx+s*dy-origin[0])/resolution)
        row=math.floor((-s*dx+c*dy-origin[1])/resolution)
        if 0<=row<data.shape[0] and 0<=col<data.shape[1]:
            checked+=1
            if data[row,col]<0 or data[row,col]>=99:raise ConstraintError('native_free_probe_blocked')
    if not checked:raise ConstraintError('no_native_free_probe')
    report={'required_cells':int(required.sum()),'missing_cells':int(missed.sum()),'free_probes':checked,
            'map_from_grid':list(map_from_grid),'resolution':resolution}
    if missed.any():raise ConstraintError('native_mask_cells_missing:'+str(report['missing_cells']))
    return report
