import sys
from pathlib import Path
from types import SimpleNamespace
import unittest
import math
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from gcu_costmap_observation import inspect
from osmag_constraint_mask import ConstraintError


class NativeObservationTest(unittest.TestCase):
    def test_rotated_local_uses_inverse_transform_for_probes(self):
        mask=np.zeros((8,8),dtype=np.int8);mask[:,0]=100
        snap=SimpleNamespace(mask=mask,resolution=1.,origin=(0.,0.))
        # Rotate a 4x4 local grid by 90 degrees into x=0..4, y=0..4.
        local=np.zeros((4,4),dtype=np.int16);local[-1,:]=100
        report=inspect(snap,local,1.,(0.,0.),(4.,0.,math.pi/2),[(2.5,1.5)])
        self.assertEqual(report['required_cells'],4)
        local[-1,1]=0
        with self.assertRaisesRegex(ConstraintError,'native_mask_cells_missing'):inspect(snap,local,1.,(0.,0.),(4.,0.,math.pi/2),[(2.5,1.5)])

    def test_float32_resolution_is_accepted_but_arbitrary_rescaling_is_not(self):
        r=.05864395131342248;snap=SimpleNamespace(mask=np.zeros((4,4)),resolution=r,origin=(0.,0.))
        inspect(snap,np.zeros((4,4)),float(np.float32(r)),(0.,0.),(0.,0.,0.),[(r,r)],full=True)
        with self.assertRaisesRegex(ConstraintError,'resolution'):inspect(snap,np.zeros((4,4)),r+1e-6,(0.,0.),(0.,0.,0.),[(r,r)])

    def test_changed_global_origin_and_unknown_probe_are_rejected(self):
        snap=SimpleNamespace(mask=np.zeros((4,4)),resolution=1.,origin=(0.,0.))
        with self.assertRaisesRegex(ConstraintError,'geometry'):inspect(snap,np.zeros((4,4)),1.,(.1,0.),(0.,0.,0.),[(1.,1.)],full=True)
        with self.assertRaisesRegex(ConstraintError,'probe_blocked'):inspect(snap,np.full((4,4),-1),1.,(0.,0.),(0.,0.,0.),[(1.,1.)])
