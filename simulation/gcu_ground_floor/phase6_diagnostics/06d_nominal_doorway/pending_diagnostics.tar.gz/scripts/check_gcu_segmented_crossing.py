#!/usr/bin/env python3
"""One explicitly enabled, independently scored simulation crossing (06B2B)."""
import argparse,json,math,time
from dataclasses import replace
from pathlib import Path
import numpy as np
from gcu_plan_validation import validate_path
from gcu_navigation_metrics import rest_window,coverage
from gcu_costmap_observation import inspect
from osmag_paper_planner import PaperPlanner
from osmag_mission_contract import make_contract,CrossingMonitor
from osmag_constraint_mask import build_mask
from gcu_segmented_executor import create_executor,simulation_guard


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true');p.add_argument('--fixture',type=Path);a=p.parse_args()
    fixture=None;fixture_sha=None
    if a.fixture:
        from gcu_mission_fixture import load_fixture,verify_runtime_sources
        fixture,fixture_sha=load_fixture(a.fixture)
        verify_runtime_sources(fixture,Path(__file__).parent)
    import os
    simulation_guard(a.execute,os.environ)
    import rclpy
    from rclpy.executors import MultiThreadedExecutor
    from rclpy.node import Node
    from rclpy.parameter import Parameter
    from rclpy.time import Time
    from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy,qos_profile_sensor_data
    from nav_msgs.msg import OccupancyGrid,Path as NavPath
    from nav2_msgs.msg import CostmapFilterInfo
    from nav2_msgs.action import ComputePathToPose
    from lifecycle_msgs.srv import ChangeState
    from rclpy.action import ActionClient
    from tf2_msgs.msg import TFMessage
    from ros_gz_interfaces.msg import Contacts
    from geometry_msgs.msg import Twist
    rclpy.init();planner=PaperPlanner(a.workspace/'assets');adapter=create_executor(planner,a.execute)
    if fixture and fixture['input_sha256']!=planner.fingerprints():raise RuntimeError('fixture_map_changed')
    evaluator=Node('gcu_segmented_evaluator',parameter_overrides=[Parameter('use_sim_time',value=True)])
    # Contact evidence must not starve mission/scan callbacks. Each node retains
    # its mutually-exclusive group; TF has its own listener group.
    executor=MultiThreadedExecutor(num_threads=3);executor.add_node(adapter);executor.add_node(evaluator)
    grids={};truth=[];matched=[];commands=[];contacts=[];counts={};plans=[];subs=[];recording=False;begin=time.monotonic();last_match=-1.
    qos=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
    def stamp(s):return s.sec+s.nanosec/1e9
    def angle(q):return math.atan2(2*q.w*q.z,1-2*q.z*q.z)
    def truth_cb(m):
        if not recording:return
        for t in m.transforms:
            if t.child_frame_id.strip('/').split('::')[-1]!='lidarbot':continue
            s=stamp(t.header.stamp);v=t.transform
            if not truth or s>truth[-1]['sim_time']:truth.append({'sim_time':s,'truth':[v.translation.x,v.translation.y,angle(v.rotation)]})
    def contact_cb(m,topic):
        counts[topic]=counts.get(topic,0)+1
        if not recording:return
        for c in m.contacts:
            names=[c.collision1.name,c.collision2.name]
            if any('cad_walls' in n or 'obstacle' in n for n in names) or not all(names) or not (any(n.startswith('ground::') for n in names) or all(n.startswith('lidarbot::') for n in names)):
                contacts.append({'sim_time':stamp(m.header.stamp),'names':names,'topic':topic})
    for key,topic in [('global','/global_costmap/costmap'),('local','/local_costmap/costmap')]:
        subs.append(evaluator.create_subscription(OccupancyGrid,topic,lambda m,k=key:grids.update({k:m}),qos))
    sensor_queue=QoSProfile(depth=100,reliability=ReliabilityPolicy.BEST_EFFORT)
    subs.append(evaluator.create_subscription(TFMessage,'/gcu_ground_truth',truth_cb,sensor_queue))
    subs.append(evaluator.create_subscription(Twist,'/cmd_vel',lambda m:commands.append({'sim_time':adapter.sim(),'v':m.linear.x,'w':m.angular.z}),100))
    subs.append(evaluator.create_subscription(NavPath,'/plan',lambda m:plans.append({'sim_time':adapter.sim(),'frame':m.header.frame_id,'points':[[p.pose.position.x,p.pose.position.y] for p in m.poses]}),10))
    collisions=json.loads((a.workspace/'assets/contact_v2/contact_manifest.json').read_text())['collisions']
    for item in collisions:
        topic=item['topic'];subs.append(evaluator.create_subscription(Contacts,topic,lambda m,t=topic:contact_cb(m,t),qos_profile_sensor_data))
    mask_pub=evaluator.create_publisher(OccupancyGrid,'/osmag/constraint_mask',qos);info_pub=evaluator.create_publisher(CostmapFilterInfo,'/osmag/constraint_filter_info',qos)
    report={'passed':False,'scope':'06B2B single real-Nav2 simulation crossing; truth evaluates only','goal':[1.4413560486865775,-12.960313240266368,0.], 'spawn':[-.5,-12.960313240266368,0.], 'preflight':{},'constraint_receipts':[]};started=[];snap=None;contract=None;published=None;last_grids={};observations={};last_errors={}
    if fixture:report.update(scope='06D nominal frozen-fixture simulation mission; truth evaluates only',fixture=fixture,fixture_sha256=fixture_sha,goal=fixture['goal'],spawn=fixture['spawn'])
    sim_timeout=fixture['simulation_timeout_s'] if fixture else 80
    wall_timeout=fixture['checker_wall_timeout_s'] if fixture else 420
    def step():
        nonlocal last_match
        executor.spin_once(timeout_sec=.015)
        for item in truth[-200:]:
            if item['sim_time']<=last_match:continue
            try:
                t=adapter.buffer.lookup_transform('map','base_footprint',Time(seconds=item['sim_time'])).transform
                pose=[t.translation.x,t.translation.y,angle(t.rotation)];actual=item['truth']
                matched.append(dict(item,estimated=pose,position_error_m=math.dist(pose[:2],actual[:2]),yaw_error_deg=math.degrees(abs(math.atan2(math.sin(pose[2]-actual[2]),math.cos(pose[2]-actual[2]))))));last_match=item['sim_time']
            except Exception:pass
        if time.monotonic()-begin>wall_timeout:raise RuntimeError('crossing_wall_timeout')
    def wait(predicate,seconds=30):
        end=time.monotonic()+seconds
        while not predicate():
            if time.monotonic()>end:raise RuntimeError('preflight_timeout')
            step()
    def transition(name,code):
        c=evaluator.create_client(ChangeState,'/'+name+'/change_state');wait(c.service_is_ready,15)
        req=ChangeState.Request();req.transition.id=code;f=c.call_async(req);wait(f.done,15)
        if not f.result().success:raise RuntimeError('lifecycle_failed:'+name+':'+str(code))
    def consumed():
        current=adapter.sim()
        for key,m in grids.items():
            s=stamp(m.header.stamp)
            # A costmap can arrive ahead of this node's /clock callback by a
            # few milliseconds. Keep the last validated observation until the
            # clock catches up; never replace it with a future-dated ACK.
            if s>current:continue
            if last_grids.get(key)==s:continue
            try:
                if s<published:raise RuntimeError('costmap_predates_mask')
                tf=[0.,0.,0.]
                if m.header.frame_id!='map':
                    if m.header.frame_id!='odom':raise RuntimeError('unexpected_costmap_frame')
                    v=adapter.buffer.lookup_transform('map','odom',Time.from_msg(m.header.stamp)).transform;tf=[v.translation.x,v.translation.y,angle(v.rotation)]
                if abs(m.info.origin.orientation.x)+abs(m.info.origin.orientation.y)+abs(m.info.origin.orientation.z)>1e-8:raise RuntimeError('rotated_grid_origin')
                data=np.asarray(m.data).reshape(m.info.height,m.info.width)
                probes=[contract.start,contract.goal[:2]] if key=='global' else [adapter.pose()[0][:2]]
                observed=inspect(snap,data,m.info.resolution,(m.info.origin.position.x,m.info.origin.position.y),tf,probes,full=key=='global')
                observations[key]=dict(observed,stamp=s);last_grids[key]=s;last_errors.pop(key,None)
                report['constraint_receipts'].append(dict(source=key,observed_at=current,**observations[key]))
            except Exception as e:
                last_errors[key]=str(e)
                if 'native_mask_cells_missing' in str(e) and len(report.setdefault('native_grid_failures',[]))<3:
                    ident=len(report['native_grid_failures'])+1
                    np.savez_compressed(a.output.parent/f'native_grid_failure_{ident}.npz',native=np.asarray(m.data,dtype=np.int16).reshape(m.info.height,m.info.width),mask=snap.mask)
                    report['native_grid_failures'].append({'source':key,'error':str(e),'stamp':s,'observed_at':current,
                        'frame':m.header.frame_id,'resolution':m.info.resolution,'origin':[m.info.origin.position.x,m.info.origin.position.y],
                        'map_from_grid_at_stamp':tf,'scope':'Diagnostic capture; does not relax or acknowledge the failed grid.'})
        return set(observations)=={'global','local'} and all(0<=current-v['stamp']<=(.75 if k=='global' else .5) for k,v in observations.items())
    try:
        wait(lambda:adapter.sim()>0 and adapter.scan_stamp is not None and adapter.buffer.can_transform('map','base_footprint',Time()),50)
        start,tfstamp=adapter.pose();now=time.monotonic()
        contract=make_contract(planner,start[:2],report['goal'][:2],report['goal'][2],mission_id=fixture['name'] if fixture else '06b2b_short_01',now=now,pose_stamp=now-(adapter.sim()-tfstamp))
        expected=tuple(fixture['expected_passages']) if fixture else ('-93',)
        if contract.passage_ids!=expected or (fixture and contract.area_ids!=tuple(fixture['expected_areas'])):raise RuntimeError('fixture_topology_changed')
        incidence={n:(v['osmAG:from'],v['osmAG:to']) for n,v in planner.passages.items()}
        snap=build_mask(planner.grid,planner.resolution,planner.origin,planner.leaves,planner.passage_segments,incidence,
            allowed_areas=contract.area_ids,open_passages=contract.passage_ids,disabled_passages=[],robot_pose=start[:2],mission_id=contract.mission_id)
        report['snapshot']=snap.report();report['contract']=contract.report()
        np.savez_compressed(a.output.parent/'constraint.npz',mask=snap.mask,combined=snap.combined,physical=planner.grid)
        msg=OccupancyGrid();msg.header.frame_id='map';msg.header.stamp=adapter.get_clock().now().to_msg();published=stamp(msg.header.stamp)
        msg.info.resolution=snap.resolution;msg.info.width=snap.mask.shape[1];msg.info.height=snap.mask.shape[0];msg.info.origin.position.x=snap.origin[0];msg.info.origin.position.y=snap.origin[1];msg.info.origin.orientation.w=1.;msg.data=snap.mask.ravel().astype(int).tolist();mask_pub.publish(msg)
        info=CostmapFilterInfo();info.type=0;info.base=0.;info.multiplier=1.;info.filter_mask_topic='/osmag/constraint_mask';info_pub.publish(info)
        for name in ['planner_server','controller_server','bt_navigator']:
            transition(name,1);transition(name,3);started.append(name)
        wait(lambda:consumed() and adapter.scan_stamp>=published and 0<=adapter.sim()-adapter.scan_stamp<=.3 and adapter.client.server_is_ready(),40)
        c=ActionClient(evaluator,ComputePathToPose,'/compute_path_to_pose');wait(c.server_is_ready)
        for segment in contract.segments:
            from geometry_msgs.msg import PoseStamped
            req=ComputePathToPose.Goal();req.planner_id='GridBased';req.use_start=False;req.goal=PoseStamped();req.goal.header.frame_id='map';req.goal.pose.position.x,req.goal.pose.position.y=map(float,segment.point);req.goal.pose.orientation.w=1.
            f=c.send_goal_async(req);wait(f.done);h=f.result()
            if not h.accepted:raise RuntimeError('segment_preflight_rejected')
            f=h.get_result_async();wait(f.done);r=f.result();points=[[p.pose.position.x,p.pose.position.y] for p in r.result.path.poses]
            check=validate_path(snap.combined,snap.resolution,snap.origin,points,.20)
            report['preflight'][str(segment.index)]={'status':r.status,'points':points,'validation':check}
            if r.status!=4 or not check['valid']:raise RuntimeError('segment_preflight_not_feasible')
        if any(abs(v['v'])+abs(v['w'])>1e-8 for v in commands):raise RuntimeError('motion_before_dispatch')
        report['ownership']={'cmd_vel':[i.node_name for i in evaluator.get_publishers_info_by_topic('/cmd_vel')],
            'navigate_status':evaluator.count_publishers('/navigate_to_pose/_action/status'),'direct_goal_publishers':evaluator.count_publishers('/phase6_disabled_goal_pose'),
            'old_bridge_subscribers':evaluator.count_subscribers('/gcu/navigation_goal')}
        if report['ownership']!={'cmd_vel':['controller_server'],'navigate_status':1,'direct_goal_publishers':0,'old_bridge_subscribers':0}:raise RuntimeError('unexpected_execution_owner')
        report['dispatch_sim']=adapter.sim();recording=True;adapter.begin(contract,consumed);report['contract']=adapter.model.contract.report()
        while adapter.model.state!='succeeded':
            step()
            if adapter.fault_reason:raise RuntimeError(adapter.fault_reason)
            if contacts:raise RuntimeError('wall_or_unclassified_contact')
            if adapter.sim()-report['dispatch_sim']>sim_timeout:raise RuntimeError('crossing_sim_timeout')
        # Score actual truth only after the executor's own action/pose/odom-rest
        # decision. It never receives this evaluator's samples.
        wait(lambda:len(truth)>10 and rest_window(truth,earliest=adapter.final_action_sim) is not None,10)
        final=truth[-1]['truth'];report['position_error_m']=math.dist(final[:2],report['goal'][:2]);delta=final[2]-report['goal'][2];report['heading_error_deg']=math.degrees(abs(math.atan2(math.sin(delta),math.cos(delta))))
        report['truth_rest']=rest_window(truth,earliest=adapter.final_action_sim);report['coverage']=coverage(truth,matched)
        report['swept_truth']=validate_path(snap.combined,snap.resolution,snap.origin,[v['truth'][:2] for v in truth],.18)
        truth_contract=replace(adapter.model.contract,start=tuple(truth[0]['truth'][:2]),pose_stamp=truth[0]['sim_time'])
        monitor=CrossingMonitor(truth_contract,planner.leaves,planner.passage_segments)
        for item in truth[1:]:monitor.observe(item['truth'][:2],item['sim_time'])
        report['truth_crossings']=monitor.events
        sends=[e for e in adapter.events if e['event']=='send'];results=[e for e in adapter.events if e['event']=='result'];first_handle=next(e['uuid'] for e in adapter.events if e['event']=='accepted' and e['token']==sends[0]['token'])
        first_result=next((e for e in results if e['uuid']==first_handle),None)
        report['handoff']={'next_goal_sim':sends[1]['sim'],'first_result':first_result,'before_intermediate_terminal':first_result is None or sends[1]['wall']<first_result['wall'],
            'confirmed_at_next_goal':sends[1]['confirmed']}
        report['handoffs']=[]
        for index in range(len(contract.passage_ids)):
            send=next(e for e in sends if e['segment']==index);next_send=next(e for e in sends if e['segment']==index+1)
            handle=next(e['uuid'] for e in adapter.events if e['event']=='accepted' and e['token']==send['token'])
            terminal=next((e for e in results if e['uuid']==handle),None)
            report['handoffs'].append({'segment':index,'passage_id':contract.passage_ids[index],'next_goal_sim':next_send['sim'],'before_intermediate_terminal':terminal is None or next_send['wall']<terminal['wall']})
        report['localization_p95_m']=float(np.percentile([v['position_error_m'] for v in matched],95));report['localization_p95_deg']=float(np.percentile([v['yaw_error_deg'] for v in matched],95))
        report['passed']=bool(monitor.confirmed==len(contract.passage_ids) and all(h['before_intermediate_terminal'] for h in report['handoffs']) and report['position_error_m']<=.20 and report['heading_error_deg']<=10 and report['swept_truth']['valid'] and report['coverage']['matched_fraction']>=.9 and report['coverage']['max_truth_gap_sim_s']<=.15 and report['localization_p95_m']<=.25 and report['localization_p95_deg']<=5 and max(abs(v['v']) for v in commands)<=.10001)
    except Exception as e:
        report['error']=repr(e);adapter.cancel('test_failure')
        try:
            end=time.monotonic()+5
            while adapter.model._unresolved() and time.monotonic()<end:step()
        except Exception:pass
    finally:
        adapter.enabled=False
        report['lifecycle_shutdown']={}
        for name in reversed(started):
            try:transition(name,4);report['lifecycle_shutdown'][name]=True
            except Exception as e:report['lifecycle_shutdown'][name]=str(e);report['passed']=False
        report.update(events=adapter.events,state=adapter.model.report(),poses=adapter.poses,tf_timing=adapter.tf_timing,scan_observations=adapter.scan_observations,truth=truth,localization=matched,commands=commands,plans=plans,contacts=contacts,contact_counts=counts,last_consumption_errors=last_errors,wall_elapsed_s=time.monotonic()-begin)
        report['contact_publishers']={c['topic']:evaluator.count_publishers(c['topic']) for c in collisions}
        report['passed']=bool(report['passed'] and all(v==1 for v in report['contact_publishers'].values()) and not contacts)
        executor.shutdown();a.output.write_text(json.dumps(report,indent=2)+'\n');adapter.destroy_node();evaluator.destroy_node();rclpy.shutdown()
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
