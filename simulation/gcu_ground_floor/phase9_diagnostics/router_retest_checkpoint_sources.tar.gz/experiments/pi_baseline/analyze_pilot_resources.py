#!/usr/bin/env python3
"""Sampled motion-interval costs for a retained pilot, with timing scope explicit."""
import argparse
import hashlib
import json
from pathlib import Path


def process_costs(samples,begin,end):
    selected=[r for r in samples if begin<=r['wall_monotonic']<=end]
    by_pid={}
    for row in selected:
        for p in row['processes']:by_pid.setdefault(p['pid'],[]).append((row['wall_monotonic'],p))
    processes=[]
    for pid,rows in by_pid.items():
        dt=rows[-1][0]-rows[0][0];cpu=rows[-1][1]['cpu_s']-rows[0][1]['cpu_s']
        processes.append(dict(pid=pid,argv=rows[0][1]['argv'],samples=len(rows),sample_span_wall_s=dt,
            cpu_delta_s=cpu,cpu_percent_one_core=100*cpu/dt if dt>0 else None,
            sampled_pss_max_kib=max(p['memory_kib']['Pss'] for _,p in rows),
            sampled_rss_max_kib=max(p['memory_kib']['Rss'] for _,p in rows)))
    sets=[{p['pid'] for p in row['processes']} for row in selected]
    stable=bool(sets and sets[0] and all(s==sets[0] for s in sets))
    span=selected[-1]['wall_monotonic']-selected[0]['wall_monotonic'] if selected else 0.
    total=sum(p['cpu_delta_s'] for p in processes)
    return dict(processes=processes,samples=len(selected),sample_span_wall_s=span,
        stable_process_set=stable,cpu_percent_one_core_total=100*total/span if span>0 and stable else None,
        sampled_concurrent_domain_pss_max_kib=max((sum(p['memory_kib']['Pss'] for p in row['processes']) for row in selected),default=None))


def analyze(folder):
    paths=dict(worker=folder/'pi_results/actor/worker.json',resources=folder/'pi_results/resources.json',
        probe=folder/'pi_results/arrival_probe.json')
    data={k:json.loads(p.read_text()) for k,p in paths.items()};worker=data['worker']
    sends=[e for e in worker['events'] if e['event']=='send']
    endings=[e for e in worker['events'] if e['event']=='fault' or (e['event']=='result' and e['outcome']=='succeeded')]
    if not sends or not endings:raise ValueError('no_motion_interval_for_resource_summary')
    begin=sends[0]['wall'];end=endings[-1]['wall']
    report=process_costs(data['resources']['samples'],begin,end)
    probe=data['probe']['rows'];rates={}
    for kind in ['scan','clock','imu']:
        rows=[r for r in probe.get(kind,[]) if begin<=r['wall']<=end]
        span=rows[-1]['wall']-rows[0]['wall'] if len(rows)>1 else 0.
        rates[kind]=dict(callbacks=len(rows),receipt_span_wall_s=span,
            callbacks_per_wall_s=(len(rows)-1)/span if span else None,
            header_sim_per_wall_s=(rows[-1]['stamp']-rows[0]['stamp'])/span if span else None,
            max_receipt_gap_wall_s=max((b['wall']-a['wall'] for a,b in zip(rows,rows[1:])),default=None))
    report.update(scope='One instrumented pilot; dispatch to last native success/fault response, excluding preprocessing/rest verification/teardown. Process CPU uses actual sample span; 100% = one core, may exceed 100%. In-process tracing is inseparable from actor cost; probe/relay are separate processes. Sampler owner is outside domain and excluded. Not a sustained or uninstrumented resource budget.',
        begin_wall=begin,end_wall=end,interval_wall_s=end-begin,actor_passed=worker['passed'],
        preprocessing_wall_s=worker['preprocessing_wall_s'],observed_rates=rates,
        inputs_sha256={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},
        analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (folder/'resource_interval_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evidence',type=Path,required=True)
    a=p.parse_args();print(json.dumps(analyze(a.evidence),indent=2))
