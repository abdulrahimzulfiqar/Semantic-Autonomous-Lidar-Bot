import datetime,json,os
from pathlib import Path
active=[]
for path in Path('/proc').glob('[0-9]*'):
    if int(path.name)==os.getpid():continue
    try:
        entries=(path/'environ').read_bytes().split(b'\0')
        domains=[v.decode(errors='replace') for v in entries if v in [b'ROS_DOMAIN_ID=197',b'ROS_DOMAIN_ID=217']]
        if domains:
            args=(path/'cmdline').read_bytes().split(b'\0')
            active.append(dict(pid=int(path.name),domains=domains,executable=args[0].decode(errors='replace')))
    except OSError:pass
print(json.dumps(dict(captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Phase 09 readiness test domains 197 and 217 only',active_processes=active,passed=not active),indent=2))
