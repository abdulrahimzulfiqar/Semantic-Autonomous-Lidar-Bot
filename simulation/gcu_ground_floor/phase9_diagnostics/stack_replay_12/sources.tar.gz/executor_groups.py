"""Explicit diagnostic separation of control timer from node data callbacks."""
import threading


def separate_mission_timer(adapter,group_factory):
    old=adapter.timer
    if old.timer_period_ns!=40000000 or not callable(old.callback):
        raise RuntimeError('unexpected_mission_timer')
    # Preserve the same callback (including its state lock), steady clock and
    # period. The separate group permits clock/sensor callbacks to progress
    # while control work occupies the timer group.
    callback=old.callback;clock=old.clock;group=group_factory()
    adapter.destroy_timer(old)
    adapter.timer=adapter.create_timer(.04,callback,callback_group=group,clock=clock)
    return dict(period_ns=40000000,callback_group='separate_mutually_exclusive',
        callback_and_clock_preserved=True)


class DedicatedTransformListener:
    """Service motion inputs on a dedicated ROS executor."""

    def __init__(self, adapter, trace=None):
        from rclpy.executors import SingleThreadedExecutor
        from rclpy.node import Node
        from rclpy.qos import qos_profile_sensor_data
        from sensor_msgs.msg import Imu, LaserScan
        from tf2_ros import TransformListener

        adapter.listener.unregister()
        self.node = Node('phase9_tf_listener')
        self.listener = TransformListener(adapter.buffer, self.node)
        if trace is not None:
            subscription = self.listener.tf_sub
            subscription.callback = trace.wrap(
                'tf_ingest', subscription.callback,
                fields=lambda message: {'stamps': [
                    [item.header.frame_id, item.child_frame_id,
                     item.header.stamp.sec + item.header.stamp.nanosec / 1e9]
                    for item in message.transforms
                    if item.child_frame_id in ('odom', 'base_footprint')
                ]})
        # Sensor freshness should reflect delivery of sensor data, not queueing
        # behind Python planning/window work. Preserve the existing callbacks,
        # their source stamps, topic names and QoS.
        for attribute, kind, topic in (
                ('scan_sub', LaserScan, '/scan'),
                ('imu_sub', Imu, adapter.imu_topic)):
            old = getattr(adapter, attribute)
            if old is not None:
                callback = old.callback
                adapter.destroy_subscription(old)
                setattr(adapter, attribute,
                        self.node.create_subscription(kind, topic, callback, qos_profile_sensor_data))
        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.node)
        self.thread = threading.Thread(target=self.executor.spin, name='phase9-tf', daemon=True)
        self.thread.start()

    def close(self):
        self.executor.shutdown()
        self.thread.join()
        self.listener.unregister()
        self.node.destroy_node()
