#!/usr/bin/env python3
"""Bounded per-host process owner for one Phase 09 pilot. No physical drivers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role',choices=['pi','simulator'],required=True)
    parser.add_argument('--workspace',type=Path,required=True)
    args=parser.parse_args();w=args.workspace.resolve()
    manifest=json.loads((w/'phase9_manifest.json').read_text())
    for name,want in manifest['files_sha256'].items():
        if hashlib.sha256((w/name).read_bytes()).hexdigest()!=want:
            raise RuntimeError('phase9_source_mismatch:'+name)
    (w/'role.pid').write_text(str(os.getpid()))
    def interrupted(*_):raise RuntimeError('pilot_interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    signal.signal(signal.SIGINT,interrupted)
    out=w/'results';out.mkdir(exist_ok=False)
    env=dict(os.environ)
    profile=json.loads((w/'profile.json').read_text())
    env.update(ROS_DOMAIN_ID='218',ROS_LOCALHOST_ONLY='0',RMW_IMPLEMENTATION='rmw_cyclonedds_cpp',
        CYCLONEDDS_URI='file://'+str(w/'dds.xml'),IGN_PARTITION=profile['partition'],
        EDGEOSMAG_PHASE9_PROFILE=str(w/'profile.json'),ROS_LOG_DIR=str(out/'ros_logs'),
        PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for path in Path('/proc').glob('[0-9]*'):
        if int(path.name)==os.getpid():continue
        try:
            if b'ROS_DOMAIN_ID=218' in (path/'environ').read_bytes().split(b'\0'):
                raise RuntimeError('phase9_domain_in_use')
        except OSError:pass
    if args.role=='simulator':
        for proc in Path('/proc').glob('[0-9]*'):
            try:
                if proc.stat().st_uid!=1000:continue
                values=dict(v.split('=',1) for v in (proc/'environ').read_text().split('\0') if '=' in v)
                if values.get('DISPLAY') and values.get('XAUTHORITY'):
                    env.update({k:values[k] for k in ['DISPLAY','XAUTHORITY','XDG_RUNTIME_DIR'] if k in values})
            except (OSError,ValueError):pass
        if not env.get('DISPLAY'):raise RuntimeError('simulator_desktop_required')
        env.update(LIBGL_ALWAYS_SOFTWARE='1',LIBGL_DRI3_DISABLE='1')
    children=[];logs=[];sampler=None;result=dict(role=args.role,passed=False,scope='One split-host simulation pilot, not a completed benchmark')
    began=time.monotonic()
    def launch(name,command):
        log=(out/(name+'.log')).open('w');logs.append(log)
        child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append((name,child));return child
    try:
        if args.role=='pi':
            from resources_phase9 import Sampler
            sampler=Sampler();sampler.start()
            launch('localization',['ros2','launch',str(w/'gcu_amcl.launch.py'),
                'map:='+str(w/'assets/gcu_ground_floor.yaml'),'params:='+str(w/'assets/amcl.yaml')])
            log=(out/'localization_ready.log').open('w');logs.append(log)
            ready=subprocess.run([sys.executable,str(w/'wait_gcu_localization.py'),'--request-updates'],
                env=env,stdout=log,stderr=subprocess.STDOUT,timeout=65)
            if ready.returncode:raise RuntimeError('pi_localization_not_ready')
            for package,name in [('nav2_planner','planner_server'),('nav2_controller','controller_server'),('nav2_bt_navigator','bt_navigator')]:
                launch(name,['/opt/ros/humble/lib/'+package+'/'+name,'--ros-args',
                    '--params-file',str(w/'assets/nav2_sensor_constraints.yaml'),
                    '-r','/goal_pose:=/phase6_disabled_goal_pose','-r','/cmd_vel:=/phase9/sim_cmd_vel'])
            actor=launch('actor',[sys.executable,str(w/'worker_phase9.py'),'--workspace',str(w),
                '--output',str(out/'actor'),'--execute'])
            actor.wait(timeout=285)
            result['passed']=actor.returncode==0 and json.loads((out/'actor/worker.json').read_text())['passed']
        else:
            observer=launch('observer',[sys.executable,str(w/'observer_phase9.py'),
                '--workspace',str(w),'--output',str(out/'observer.json')])
            launch('simulator',['ros2','launch',str(w/'gcu_phase9_sim.launch.py'),
                'assets:='+str(w/'assets/contact_v2'),'world:='+str(w/'assets/contact_v2/world.sdf')])
            observer.wait(timeout=345)
            result['passed']=observer.returncode==0
    except Exception as error:result['error']=repr(error)
    finally:
        if args.role=='simulator':
            try:
                from gcu_process_audit import stop_truth_bridge
                from gcu_quiescent_shutdown import stop_quiescent_simulator
                result['truth_shutdown']=stop_truth_bridge(env['IGN_PARTITION'])
                result['simulator_shutdown']=stop_quiescent_simulator(env['IGN_PARTITION'])
            except Exception as error:result['shutdown_error']=repr(error)
        for name,child in reversed(children):
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGINT)
                try:child.wait(timeout=12)
                except subprocess.TimeoutExpired:
                    result.setdefault('forced_cleanup',[]).append(name)
                    os.killpg(child.pid,signal.SIGTERM)
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        if sampler:
            sampler.stop();(out/'resources.json').write_text(json.dumps(dict(scope='One-second process RSS/PSS and CPU-time samples; pilot, not repeated benchmark',samples=sampler.rows),indent=2)+'\n')
        for log in logs:log.close()
        result.update(process_exits={name:c.returncode for name,c in children},elapsed_wall_s=time.monotonic()-began)
        result['passed']=bool(result['passed'] and not result.get('forced_cleanup') and
            all(c.returncode==0 for _,c in children) and not result.get('shutdown_error'))
        if args.role=='simulator':
            result['passed']=bool(result['passed'] and result.get('truth_shutdown',{}).get('passed')
                and result.get('simulator_shutdown',{}).get('passed'))
        (out/'role.json').write_text(json.dumps(result,indent=2)+'\n')
    return 0 if result['passed'] else 1


if __name__=='__main__':
    try:
        code=main()
    except Exception as error:
        # Preserve a source/profile/display startup failure even before child
        # ownership begins, so the host need not wait for a nonexistent role.
        if '--workspace' in sys.argv:
            workspace=Path(sys.argv[sys.argv.index('--workspace')+1])
            result=workspace/'results/role.json'
            if not result.exists():
                result.parent.mkdir(parents=True,exist_ok=True)
                result.write_text(json.dumps(dict(passed=False,startup_failure=repr(error),
                    process_exits={},scope='Pilot startup failure; no motion result'),indent=2)+'\n')
        import traceback
        traceback.print_exc()
        code=1
    raise SystemExit(code)
