# Actual Pi processor-in-loop experiments

## Quick summary

This separate harness keeps Gazebo, simulated hardware drivers and ground-truth
recording in Ubuntu. The Pi runs AMCL/EKF, osmAG preprocessing/routing/window
management and native Nav2. Initial trials are bounded setup pilots. They do not
complete Phase 09 or establish real-time capacity from a slow simulator.

## Scope and isolation

- Dedicated ROS domain **218**; only `/phase9/sim_cmd_vel` feeds the simulated
  twist relay. No physical robot driver is started on the Pi.
- An explicit pinned JSON/DDS profile authorizes the generated simulation actor.
  The original loopback-only execution guard and all accepted sources stay intact.
- The preparer derives a private executor copy by replacing only the guard
  definition with that profile import. It verifies that the remaining Python AST
  is identical. Sensor/TF/constraint freshness, action handling and speed limits
  are preserved.
- Ground truth and contact recording exist only on the simulator side. The Pi
  actor has no ground-truth subscription or ground-truth input file. Independent
  scoring later reads the frozen Pi inputs and simulator observations.
- Pilot-only changes: two-host DDS profile, simulated command-topic remap and
  disabled camera sensor/image bridge on the simulator. No LLM or perception
  processing runs. Keep cooling/power/network/software version differences explicit.

## Initial pilot protocol

Start approximately `(-0.5, -12.9603, 0)` and navigate to
`(1.0, -12.9603, 0)`, crossing passage `-93`. The Pi actor has a 260 s wall budget
and 90 s simulated motion budget. Process-owner and host watchdogs allow bounded
setup/cleanup around that interval. Failures are retained and never converted to
success by relaxing the established freshness or geometry checks.

Correctness gates inherit the Phase 06/07 policy: at most 0.20 m / 10° final error,
0.25 m / 5° p95 localization error, at least 90% truth/TF matching, maximum 0.15 s
truth gap, independent sampled rest, physical swept clearance, no classified wall
contacts and an unchanged 0.1 m/s linear command limit. This short pilot does not
require three planning windows or a proxy; longer-window behavior was covered by
the earlier native fixture and remains a future split-host test.

The sampler records per-process cumulative CPU seconds and RSS/PSS approximately
once per wall second, plus host memory, temperature and frequency. Its process
scope is domain-218 children; the recorder thread/owner is outside that ROS domain.
CPU percentages, peaks between samples and whole-device power are not inferred.
Startup, preprocessing and movement intervals must be separated when reporting.

## Files

`prepare.py` builds separate role trees from an accepted baseline export.
`run_pilot.py` deploys them and supervises one trial through SSH and UTM's guest
agent. `run_role.py` owns local processes. `worker.py` is the Pi actor;
`observer.py` is the laptop-only recorder; `resources.py` samples the Pi.
`score.py` checks motion independently afterward. Source manifests and archives
pin the exact executed code/configuration and preserve failed attempts.

Use new staging, remote workspace and evidence paths for every attempt. Do not
reuse or modify the accepted Phase 07/08 workspaces. The plan and current results
belong in `docs/research/osm-AG/plans/09_PI4B_NAVIGATION_BASELINE.md` and
`simulation/gcu_ground_floor/phase9_diagnostics/`.
