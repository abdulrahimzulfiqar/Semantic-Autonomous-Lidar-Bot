#!/usr/bin/env python3
"""Prepare isolated Pi/simulator staging trees without changing accepted sources."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET


def derive_executor(source):
    tree=ast.parse(source)
    original=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name!='simulation_guard']
    guards=[i for i,n in enumerate(tree.body) if isinstance(n,ast.FunctionDef) and n.name=='simulation_guard']
    if len(guards)!=1:raise ValueError('unexpected_executor_guard')
    tree.body[guards[0]]=ast.ImportFrom(module='profile_phase9',names=[ast.alias(name='simulation_guard')],level=0)
    derived=ast.unparse(ast.fix_missing_locations(tree))+'\n'
    checked=[n for n in ast.parse(derived).body if not isinstance(n,ast.ImportFrom) or n.module!='profile_phase9']
    if ast.dump(ast.Module(body=original,type_ignores=[]))!=ast.dump(ast.Module(body=checked,type_ignores=[])):
        raise ValueError('executor_behavior_changed_beyond_guard')
    return derived


def prepare(baseline,destination,pi_root,sim_root,pi_ip,sim_ip,session):
    import yaml
    destination.mkdir(exist_ok=False)
    sources=Path(__file__).resolve().parent
    scripts=sources.parents[1]/'scripts'
    pi=destination/'pi';sim=destination/'simulator'
    pi.mkdir();(pi/'assets').mkdir()
    shutil.copytree(baseline,sim)
    # Baseline paths in accepted SDF/YAML are rewritten only in this derived copy.
    old='/home/ubuntu/edgeosmag_phase8_amcl_baseline_ws_01'
    for path in sim.rglob('*'):
        if path.is_file() and path.suffix in ['.py','.yaml','.sdf','.urdf','.xml']:
            path.write_text(path.read_text().replace(old,str(sim_root)))
    for name in ['gcu_ground_floor.osm','gcu_ground_floor.pgm','gcu_ground_floor.yaml',
                 'amcl.yaml','nav2_sensor_constraints.yaml','navigate_strict.xml',
                 'navigate_through_strict.xml','regions_pixels.geojson']:
        shutil.copy2(sim/'assets'/name,pi/'assets'/name)
    for name in ['gcu_amcl.launch.py','gcu_amcl_initial_pose.py','wait_gcu_localization.py']:
        shutil.copy2(baseline/name,pi/name)
    params=yaml.safe_load((pi/'assets/nav2_sensor_constraints.yaml').read_text())
    bt=params['bt_navigator']['ros__parameters']
    bt['default_nav_to_pose_bt_xml']=str(pi_root/'assets/navigate_strict.xml')
    bt['default_nav_through_poses_bt_xml']=str(pi_root/'assets/navigate_through_strict.xml')
    (pi/'assets/nav2_sensor_constraints.yaml').write_text(yaml.safe_dump(params,sort_keys=False))
    files={'worker.py':'worker_phase9.py','resources.py':'resources_phase9.py',
           'simulation_profile.py':'profile_phase9.py','run_role.py':'run_role.py'}
    for before,after in files.items():shutil.copy2(sources/before,pi/after)
    # Copy the transitive local imports of the existing execution components.
    pending=['osmag_paper_planner','gcu_segmented_executor','gcu_rolling_window_manager']
    seen=set()
    while pending:
        name=pending.pop()
        if name in seen:continue
        seen.add(name);text=(scripts/(name+'.py')).read_text()
        shutil.copy2(scripts/(name+'.py'),pi/(name+'.py'))
        for node in ast.walk(ast.parse(text)):
            if isinstance(node,ast.ImportFrom) and node.module and (scripts/(node.module+'.py')).is_file():pending.append(node.module)
    original=(pi/'gcu_segmented_executor.py').read_text()
    (pi/'gcu_segmented_executor.py').write_text(derive_executor(original))
    derivation=dict(original_sha256=hashlib.sha256(original.encode()).hexdigest(),
        derived_sha256=hashlib.sha256((pi/'gcu_segmented_executor.py').read_bytes()).hexdigest(),
        scope='Only simulation_guard definition replaced by explicit Phase 09 profile import; remaining AST identical')
    (pi/'executor_derivation.json').write_text(json.dumps(derivation,indent=2)+'\n')
    shutil.copy2(sources/'observer.py',sim/'observer_phase9.py')
    shutil.copy2(sources/'run_role.py',sim/'run_role.py')
    for name in ['gcu_process_audit.py','gcu_quiescent_shutdown.py']:
        shutil.copy2(scripts/name,sim/name)
    launch=(sim/'gcu_phase6_sim.launch.py').read_text()
    needle="'topics.navigation.topic':'cmd_vel'"
    if launch.count(needle)!=1:raise ValueError('unexpected_command_relay')
    launch=launch.replace(needle,"'topics.navigation.topic':'/phase9/sim_cmd_vel'")
    launch=launch.replace("        Node(package='ros_gz_image', executable='image_bridge', arguments=['/camera/image_raw']),\n",'')
    (sim/'gcu_phase9_sim.launch.py').write_text(launch)
    robot=sim/'assets/contact_v2/robot.sdf';tree=ET.parse(robot)
    camera_removed=0
    for link in tree.findall('./model/link'):
        for sensor in list(link.findall('sensor')):
            if sensor.get('type')=='camera':link.remove(sensor);camera_removed+=1
    tree.write(robot,encoding='unicode')
    for role,folder,ip in [('navigation_pi',pi,pi_ip),('simulator',sim,sim_ip)]:
        root=ET.Element('CycloneDDS');domain=ET.SubElement(root,'Domain',id='any')
        general=ET.SubElement(domain,'General');interfaces=ET.SubElement(general,'Interfaces')
        ET.SubElement(interfaces,'NetworkInterface',address=ip);ET.SubElement(general,'AllowMulticast').text='false'
        discovery=ET.SubElement(domain,'Discovery');ET.SubElement(discovery,'ParticipantIndex').text='auto'
        ET.SubElement(discovery,'MaxAutoParticipantIndex').text='32'
        peers=ET.SubElement(discovery,'Peers')
        for peer in [pi_ip,sim_ip]:ET.SubElement(peers,'Peer',Address=peer)
        ET.indent(root);(folder/'dds.xml').write_text(ET.tostring(root,encoding='unicode')+'\n')
        profile=dict(scope='gcu_phase9_processor_in_loop',role=role,domain=218,
            partition='gcu_phase9_'+session,pi_ip=pi_ip,simulator_ip=sim_ip,
            command_topic='/phase9/sim_cmd_vel',camera_sensors_removed=camera_removed,
            dds_sha256=hashlib.sha256((folder/'dds.xml').read_bytes()).hexdigest())
        (folder/'profile.json').write_text(json.dumps(profile,indent=2)+'\n')
        manifest={str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in folder.rglob('*') if p.is_file()}
        (folder/'phase9_manifest.json').write_text(json.dumps(dict(files_sha256=manifest),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['baseline','destination','pi-root','sim-root']:p.add_argument('--'+name,type=Path,required=True)
    for name in ['pi-ip','sim-ip','session']:p.add_argument('--'+name,required=True)
    a=p.parse_args();prepare(a.baseline,a.destination,a.pi_root,a.sim_root,a.pi_ip,a.sim_ip,a.session)
