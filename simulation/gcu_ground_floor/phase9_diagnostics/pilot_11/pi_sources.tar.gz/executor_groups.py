"""Explicit diagnostic separation of control timer from node data callbacks."""


def separate_mission_timer(adapter,group_factory):
    old=adapter.timer
    if old.timer_period_ns!=40000000 or not callable(old.callback):
        raise RuntimeError('unexpected_mission_timer')
    # Preserve the same callback (including its state lock), steady clock and
    # period. The separate group permits clock/sensor callbacks to progress
    # while control work occupies the timer group.
    callback=old.callback;clock=old.clock;group=group_factory()
    adapter.destroy_timer(old)
    adapter.timer=adapter.create_timer(.04,callback,callback_group=group,clock=clock)
    return dict(period_ns=40000000,callback_group='separate_mutually_exclusive',
        callback_and_clock_preserved=True)
