#!/usr/bin/env python3
"""Independent Pi process: read-only clock/sensor/TF callback receipt trace."""
import argparse
from collections import defaultdict,deque
import json
import os
from pathlib import Path
import signal
import time


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if os.environ.get('ROS_DOMAIN_ID')!='218':p.error('phase9_domain_required')
    import rclpy
    from rclpy.qos import QoSProfile,ReliabilityPolicy,qos_profile_sensor_data
    from rosgraph_msgs.msg import Clock
    from sensor_msgs.msg import LaserScan,Imu
    from tf2_msgs.msg import TFMessage
    rclpy.init(args=[]);node=rclpy.create_node('phase9_independent_arrival_probe')
    rows={};counts=defaultdict(int);running=True
    def append(kind,stamp,**extra):
        rows.setdefault(kind,deque(maxlen=40000)).append(dict(wall=time.monotonic(),stamp=stamp,**extra));counts[kind]+=1
    def stamp(t):return t.sec+t.nanosec/1e9
    def transforms(m):
        for t in m.transforms:
            if (t.header.frame_id,t.child_frame_id) in [('odom','base_footprint'),('map','odom')]:
                append('tf',stamp(t.header.stamp),parent=t.header.frame_id,child=t.child_frame_id)
    subscriptions=[node.create_subscription(Clock,'/clock',lambda m:append('clock',stamp(m.clock)),QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT)),
        node.create_subscription(LaserScan,'/scan',lambda m:append('scan',stamp(m.header.stamp)),qos_profile_sensor_data),
        node.create_subscription(Imu,'/imu_broadcaster/imu',lambda m:append('imu',stamp(m.header.stamp)),qos_profile_sensor_data),
        node.create_subscription(TFMessage,'/tf',transforms,QoSProfile(depth=100,reliability=ReliabilityPolicy.BEST_EFFORT))]
    def stop(*_):
        nonlocal running
        running=False
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    began=time.monotonic()
    try:
        while running and rclpy.ok() and time.monotonic()-began<360:rclpy.spin_once(node,timeout_sec=.01)
    finally:
        a.output.write_text(json.dumps(dict(scope='Independent Pi callback receipts on system monotonic time; no ROS simulated clock or ground-truth input; not wire arrival timestamps',
            elapsed_wall_s=time.monotonic()-began,total_calls=dict(counts),maximum_rows_per_kind=40000,rows={k:list(v) for k,v in rows.items()}),indent=2)+'\n')
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()


if __name__=='__main__':main()
