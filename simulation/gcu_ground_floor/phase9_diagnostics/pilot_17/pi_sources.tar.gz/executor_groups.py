"""Explicit diagnostic separation of control timer from node data callbacks."""
import threading


def separate_mission_timer(adapter,group_factory):
    old=adapter.timer
    if old.timer_period_ns!=40000000 or not callable(old.callback):
        raise RuntimeError('unexpected_mission_timer')
    # Preserve the same callback (including its state lock), steady clock and
    # period. The separate group permits clock/sensor callbacks to progress
    # while control work occupies the timer group.
    callback=old.callback;clock=old.clock;group=group_factory()
    adapter.destroy_timer(old)
    adapter.timer=adapter.create_timer(.04,callback,callback_group=group,clock=clock)
    return dict(period_ns=40000000,callback_group='separate_mutually_exclusive',
        callback_and_clock_preserved=True)


class DedicatedTransformListener:
    """Service the existing mission buffer on a dedicated ROS executor."""

    def __init__(self, adapter, trace=None):
        from rclpy.executors import SingleThreadedExecutor
        from rclpy.node import Node
        from tf2_ros import TransformListener

        adapter.listener.unregister()
        self.node = Node('phase9_tf_listener')
        self.listener = TransformListener(adapter.buffer, self.node)
        if trace is not None:
            subscription = self.listener.tf_sub
            subscription.callback = trace.wrap(
                'tf_ingest', subscription.callback,
                fields=lambda message: {'stamps': [
                    [item.header.frame_id, item.child_frame_id,
                     item.header.stamp.sec + item.header.stamp.nanosec / 1e9]
                    for item in message.transforms
                    if item.child_frame_id in ('odom', 'base_footprint')
                ]})
        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.node)
        self.thread = threading.Thread(target=self.executor.spin, name='phase9-tf', daemon=True)
        self.thread.start()

    def close(self):
        self.executor.shutdown()
        self.thread.join()
        self.listener.unregister()
        self.node.destroy_node()
