# Phase 09 diagnostic checkpoint: callback and scan delivery

## Quick summary

- **Scope:** Full-stack Pi pilots with independent clock/sensor receipts and callback timing, at target 0.2× simulation time.
- **Finding:** Mission callbacks can lag another Pi receiver. Separate trials also show delayed/missing scan receipts across the host boundary.
- **Result:** Timer separation permits a passage crossing in one attempt; a reliable scan relay still fails timing. No complete mission or performance budget is established. All 207 tests pass.
- **Remaining:** Improve/isolate the delivery path, then retest a bounded mission and freeze repeated measurements. Phase 09 remains open; experimental options stay separate.

## Why this follows local replay

[Checkpoint 09C](09C_PI4B_LOCAL_REPLAY.md) reproduces an intermittent observation
gap without Wi-Fi sensor delivery. These pilots add two complementary views:

- Inside the mission process, wrappers record callback entry/return and ROS
  clock values for the control timer, clock, scans, IMU, grid updates, action
  callbacks, window heartbeat and driver loop.
- A separate Pi process records clock, scan, IMU and relevant TF callback
  receipts using the same host monotonic clock, without a simulated-time clock,
  commands or ground truth.

These are **callback timestamps**, not wire-arrival timestamps. Different DDS
readers may receive different subsets of best-effort data. The trace can expose
receiver/process differences; it cannot by itself isolate network, middleware,
callback-group scheduling, thread scheduling or lock waits. Retention is bounded
and total/retained counts are recorded. Instrumentation adds CPU/memory costs,
so these trials are not an uninstrumented performance benchmark.

## Retained bounded attempts

All motion attempts request the same approximately 1.5 m route across passage
`-93`, with the same map, 0.1 m/s command limit, 0.15 s TF/observation-gap limits
and 0.3 s scan-age limit. Physics targets 0.2× and clock transport is capped at
100 publications per wall second. Wi-Fi power saving remains off.

| Pilot | Declared experimental options | Recorded result |
| --- | --- | --- |
| 10 | Timing trace; original callback groups and scan transport | Goal accepted; stale-scan guard stops execution. |
| 11 | Trace + separate mission timer group | Actor confirms passage crossing; stale TF later stops execution before the final goal. |
| 12 | Trace + separate timer + reliable scan hop | Observer CLI integration error during startup. Pi owner deliberately stopped; no mission starts. Failed startup and shutdown reports retained. |
| 13 | Corrected observer CLI; same reliable scan-hop options | Goal accepted; stale-scan guard stops execution. Scan-hop verification also fails coverage. |

These are sequential diagnostic variants, not randomized repetitions or a
success-rate comparison. All nominal motion attempts fail independent mission
scoring. The role owners terminate their children. Independent truth records
sampled rest after the failures and no classified wall contacts; this does not
convert them into successful missions or general safety validation.

## Finding 1: mission-process clock lag

In pilot 10 the actor clock callback goes **0.987 wall seconds** without an
update while its control timer continues running. The independent Pi probe
records **39 clock callbacks during that interval**, and the driver node's clock
also advances before the actor's clock catches up. Some of the interval is a
shared receipt gap too; it is not exclusively an actor-only stall.

The actor eventually jumps from ROS time 16.379 to 16.766, processes an older
scan stamped 16.4, and stops on the existing scan-age guard. The independent
probe had already recorded scan 16.7. This demonstrates a receiver/callback
processing difference and motivates separating control work from the node's
default data callback group. It does not establish a unique root cause.

![Pilot 10: independent and driver clocks advance while the mission clock remains flat; control timer callbacks continue](../../../../simulation/gcu_ground_floor/phase9_diagnostics/pilot_10/callback_timing.png)

The optional timer change preserves the **same callback, state lock, steady
clock and 40 ms period**, but gives the timer its own mutually exclusive group.
Clock/sensor callbacks remain in the node's default group. Tests check that the
callback/clock identities and period are preserved and unexpected timer layouts
are rejected. No age, geometry or speed threshold changes.

Pilot 11 runs for 7.861 simulated seconds after dispatch, with approximately
0.771 m independently recorded net displacement and one actor-confirmed passage
crossing. It is better progress in that attempt, **not proof of a reliable fix**.

## Finding 2: scan delivery remains a separate problem

Near pilot 11's final fault, Ubuntu's source observer records scans 24.9, 25.0
and 25.1. None appears in the independent Pi probe's retained receipt log; it
records 24.8 and then 25.2. The map-to-odom TF last observed on the Pi is stamped
25.0, consistent with AMCL's configured 0.2 s transform tolerance after scan
24.8. When the actor clock reaches 25.162, the latest composed TF is too old
for the unchanged 0.15 s guard. The mission stops correctly under that policy.
Absence from a callback log is not a direct measurement of network packet loss.

The next variant adds a simulation-only reliable DDS scan hop: Ubuntu subscribes
to its local source scan, publishes `/phase9/remote_scan` with reliable depth-5
QoS, and a Pi receiver republishes the unchanged message locally as `/scan`.
The Ubuntu truth observer continues to observe the original source scan topic,
not the round-tripped Pi output. Both relay endpoints hash the serialized scan
and record the original header stamp. No scan is freshened by relabelling it.

Pilot 13 still fails. During its declared mission interval, the source observer
and sender each record three unique scan stamps; the receiver records two.
Stamp **18.1** is absent, and all matched scans have identical serialized hashes.
The receiver has a **2.301 s wall-time gap** between scans 18.0 and 18.2. The
mission stops before the latter is received, when its latest processed scan is
0.347 simulated seconds old. Reliable QoS alone did not establish timely or
complete callback receipt in this setup. No cross-host one-way latency is
inferred from unsynchronized host monotonic clocks.

## Evidence and reproduction

- [Callback pilot summary](../../../../simulation/gcu_ground_floor/phase9_diagnostics/callback_pilot_summary.json): independent sampled displacement/rest and retained resource samples.
- [Pilot 10 correlation](../../../../simulation/gcu_ground_floor/phase9_diagnostics/pilot_10/callback_analysis.json).
- [Pilot 11 correlation](../../../../simulation/gcu_ground_floor/phase9_diagnostics/pilot_11/callback_analysis.json).
- [Pilot 13 scan-hop verification](../../../../simulation/gcu_ground_floor/phase9_diagnostics/pilot_13/scan_link_analysis.json).
- [Final process audit](../../../../simulation/gcu_ground_floor/phase9_diagnostics/callback_process_audit.json): no owned experiment processes on either host; operating systems/desktops left running.
- [Harness scope and options](../../../../experiments/pi_baseline/README.md).

Each trial retains source/configuration archives, per-host manifests, native
logs, actor/probe traces, independent truth/contact observations and failed
mission scores. All **207 tests pass**, including trace delegation/exception
identity, bounded concurrent retention, same-host trace correlation, timer
preservation and rejection of missing/changed scan content.

From the repository root, regenerate a callback correlation with:

```bash
PYTHONDONTWRITEBYTECODE=1 docs/research/osm-AG/osm_cad_pipeline/osmAG-from-cad/venv/bin/python \
  experiments/pi_baseline/analyze_callbacks.py \
  --evidence simulation/gcu_ground_floor/phase9_diagnostics/pilot_11
```

Use `analyze_scan_link.py` for pilot 13 and `plot_callbacks.py` for the retained
failure plots. These analyzers do not replace independent mission scoring.

## What remains together in Phase 09

1. Improve or isolate the cross-host delivery/receiver path and trace any
   remaining local scheduling stalls. A closer-router or alternate-network
   retest would help distinguish wireless conditions from software behavior;
   faster Internet alone does not establish a timely LAN sensor stream.
2. Obtain a fully scored closed-loop mission, then freeze tasks and repeat
   reliability/resource measurements under declared rates. Even a passing
   0.2× functional trial would not prove full-rate Pi capacity.

The original executor's production source and frozen Phase 07/08 baselines are
unchanged by these optional callback-group/scan-hop variants. They remain
explicit experimental profile flags, disabled by default. No complete Phase 09
result, measured camera/LLM headroom or paper-ready performance advantage is
claimed here.
