# Phase 09: actual Pi 4B navigation baseline

## Quick summary

- **Goal:** Measure the accepted osmAG + AMCL + Nav2 workload on actual Pi hardware before adding camera or language inference.
- **Status:** Planned after Phase 08 closure; no Pi deployment or hardware result has been achieved by this plan.
- **Setup:** Pi runs navigation compute; another machine runs Gazebo/evaluation. Keep the working AMCL/EKF and separate structural prototype unchanged.
- **Finish when:** Repeated frozen tasks establish reliability, latency and a measured CPU/RAM/network/thermal budget, with source and hardware versions recorded.

## Why this is next

Phase 08 established no controlled CPU/RAM advantage for structural localization.
The user chose to retain AMCL and prioritize the core EdgeOsmAG workload. Measure
what actually limits the Pi before optimizing or replacing a working component.
This phase also freezes the implemented single-floor simulation stack; it does
not claim complete reproduction of the authors' localization architecture.

## Bounded sequence

1. **Inventory and compatibility.** Record Pi model/RAM, OS/architecture, ROS/Nav2
   versions, cooling/power, storage and network. Verify supported packages and
   freeze launch/config/source versions. Record any unavoidable difference from
   the accepted Humble setup. Establish a separately versioned ROS network
   profile: the current localhost-only Cyclone DDS configuration cannot connect
   the Pi to the external simulator. Measure network/middleware overhead.
2. **Navigation-only profiling.** Run existing short accepted tasks with Gazebo
   and independent truth evaluation off the Pi. Preserve map/footprint, AMCL/EKF,
   velocity limits, controller settings and goal semantics. Distinguish startup,
   preprocessing, online planning, localization/control and idle resource use.
   Use bounded trials with explicit wall budgets; retain failed/aborted attempts.
3. **Repeat and set the budget.** Repeat declared tasks and report distributions
   of arrival, localization errors, contacts/failures, timing and resource use.
   Identify actual bottlenecks before changing parameters. Freeze an acceptable
   baseline and reserve measured headroom for later perception/language tests.

## Required measurements

- Per-process and whole navigation-workload CPU time/utilization and RAM, with
  RSS/PSS definitions and sampling intervals stated.
- Planning/action latency, controller update/deadline behavior, scan/TF freshness,
  task completion/arrival, localization errors and failure/shutdown outcomes.
- Network throughput/latency and clock/time policy; distinguish simulated time
  from wall time and avoid attributing slow external simulation to Pi performance.
- Temperature, throttling and sustained-load behavior; power/energy only where
  an appropriate measurement method is available.
- No simulator, ground-truth evaluator, Foxglove UI or unrelated host compute
  included as Pi navigation cost. Record any offboard preprocessing explicitly.

No CPU percentage or RAM target is invented before the actual Pi inventory and
baseline measurement. A successful run alone is insufficient to establish a
sustained resource budget. If a required task fails, record the limitation and
make a bounded change followed by matched verification.

## Following experiments

Phase 10 adds camera perception and checks useful area/object associations plus
navigation impact. Phase 11 adds asynchronous, validated language-to-task logic,
with local/offboard inference separated. Phase 12 compares navigation alone,
+camera, +language and +both under matched tasks and hardware. The research
contribution is the measured architecture/tradeoff, not merely the presence of
those components.

Reopen structural localization only if Pi profiling identifies a material AMCL
bottleneck, required cases expose localization failures, or a compatible author
implementation becomes available. Preserve its existing experimental code and
inputs for that optional comparison.
